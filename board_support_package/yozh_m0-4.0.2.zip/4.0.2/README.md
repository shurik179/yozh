# Arduino board support package

This package contains Arduino board support files for Yozh Robotics controller by Island Robotics LLC (https://yozh.rtfd.io/).
This package is version 4.0.2, built on 2023-11-13.

It relies on Adafruit's SAMD board support package; thus, users need to have that package installed. 
Please see installation instructions here: https://learn.adafruit.com/add-boards-arduino-v164/setup

This package was built using tools from https://github.com/shurik179/SAMD-custom-board repository. 

